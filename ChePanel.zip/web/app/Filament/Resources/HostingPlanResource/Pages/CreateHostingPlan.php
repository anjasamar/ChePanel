<?php

namespace App\Filament\Resources\HostingPlanResource\Pages;

use App\Filament\Resources\HostingPlanResource;
use Filament\Resources\Pages\CreateRecord;

class CreateHostingPlan extends CreateRecord
{
    protected static string $resource = HostingPlanResource::class;
}
