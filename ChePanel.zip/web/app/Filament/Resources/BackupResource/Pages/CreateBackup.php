<?php

namespace App\Filament\Resources\BackupResource\Pages;

use App\Filament\Resources\BackupResource;
use Filament\Resources\Pages\CreateRecord;

class CreateBackup extends CreateRecord
{
    protected static string $resource = BackupResource::class;
}
