<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PHPMyAdminSSOToken extends Model
{
    use HasFactory;

    protected $table = 'phpmyadmin_sso_tokens';

}
