<?php

return [
    'name' => 'Microweber',
    'sharedPaths' => [
        'app' => '/usr/share/microweber/latest',
        'modules' => '/usr/share/microweber/latest/userfiles/modules',
        'templates' => '/usr/share/microweber/latest/userfiles/templates',
    ],

];
