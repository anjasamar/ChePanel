<?php

namespace Modules\Microweber\Filament\Clusters\Microweber\Resources\InstallationResource\Pages;

use Filament\Resources\Pages\CreateRecord;
use Modules\Microweber\Filament\Clusters\Microweber\Resources\InstallationResource;

class CreateInstallation extends CreateRecord
{
    protected static string $resource = InstallationResource::class;
}
