<?php

return [
    'name' => 'Customer',
];
