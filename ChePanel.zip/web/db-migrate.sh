CHE_PHP=/usr/local/che/php/bin/php
$CHE_PHP artisan migrate
#$CHE_PHP artisan l5-swagger:generate
