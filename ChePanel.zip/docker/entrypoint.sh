service mysql start
service che start

tail -f /dev/null
