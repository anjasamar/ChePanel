# Installation

To install ChePanel, you need to run this commands:

```
wget https://raw.githubusercontent.com/anjasamar/ChePanel/main/installers/install.sh && chmod +x install.sh && ./install.sh
```

The admin panel can be opened on port: yourserver.com:8443
