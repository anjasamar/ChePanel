# Features

CHE PANEL supports a variety of server application types, including:

- **Apache + PHP:** Versions 7.4, 8.0, 8.1, 8.3, and 8.4
- **Apache + NodeJS**
- **Apache + Python**
- **Apache + Ruby**
- **Apache + Docker (Via Proxy Reverse)**
